export const config = {
    "serverUrl": "/backend/"
};