<?php namespace App\Libraries\Authorization;

class SignatureInvalidException extends \UnexpectedValueException
{

}