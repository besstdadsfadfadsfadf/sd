<?php namespace App\Libraries\Authorization;

class BeforeValidException extends \UnexpectedValueException
{

}